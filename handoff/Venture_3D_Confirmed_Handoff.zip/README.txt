VENTURE 3D STUDIO: CONFIRMED MODEL HANDOFF
==========================================
Project: My Venture Project
Model:   Doctor Mascot (Brand mascot)
Version: 1, confirmed 2026-11-04T17:19:40.400Z
Size:    59.68 x 120.03 x 52.66 cm (width x height x depth)

WHAT IS IN THIS ZIP
model.glb            The confirmed 3D model. Textures are stored inside the file.
model-manifest.json  Machine-readable details (see schemaVersion).
project.json         Editable copy. Open it with Import Project in the studio.
preview.png          A picture rendered from model.glb.
README.txt           This file.

FOR MISSION 3
1. Keep this ZIP. Unzip it when you are ready to add the model to your website.
2. Put model.glb, model-manifest.json and preview.png together in one website folder.
3. Show model.glb with a Three.js GLTFLoader or the <model-viewer> web component.
4. Use "camera", "scene" and "hotspots" in model-manifest.json to match this design.
5. Use preview.png as the loading image and as the fallback if 3D is unavailable.

GOOD TO KNOW
- GLB units are metres. Y is up and the front of the model faces +Z.
- Check model.glb against files.model.sha256 in the manifest to confirm it is unchanged.
- Confirming did not publish anything or change your venture website.
- Source: Stylized approximation, hand-built as editable parts during development by looking at the Mission 1 concept image. It is not an automatic image-to-3D reconstruction, and proportions and details are interpreted.
